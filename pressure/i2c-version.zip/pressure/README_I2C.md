# I2C Version Branch
This branch contains ADS1115 I2C implementation.
