print('I2C basic GUI placeholder')
