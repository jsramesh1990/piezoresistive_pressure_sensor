I2C wiring instructions.
